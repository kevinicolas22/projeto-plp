module Treino where

type TipoTreino = String

type Exercicios = [String]

--Definição de um treino
data Treino = Treino
    {   
        tipoTreino :: TipoTreino,
        exercicios :: Exercicios
    }

class Stringify a where
    toString :: a -> String
    
instance Stringify Treino where
    toString (Treino tipoTreino exercicios) =  tipoTreino ++ "," ++
                                                        show(exercicios)

instance Show Treino where
    show treino = "=> TIPO DE TREINO: " ++ tipoTreino treino++ "\n" ++
                  "   EXERCÍCIOS: " ++ alignExercicios (exercicios treino)

alignExercicios :: [String] -> String
alignExercicios [] = ""
alignExercicios (x:xs) = x ++ "\n" ++ unlines (map ("               " ++) xs)