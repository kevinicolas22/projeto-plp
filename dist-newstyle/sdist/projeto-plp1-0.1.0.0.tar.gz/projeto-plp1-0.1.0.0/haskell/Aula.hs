module Aula where
import Planos
import Data.List (intercalate)
import Data.Text (Text)
type Planos= [PlanoTipo]
data Aula = Aula {
    nomeAula :: String,
    horarioAula :: String,
    planosPermitidos :: Planos
} 


instance Show Aula where
    show aula = "=> " ++ nomeAula aula ++ "\n" ++
                "   Horário: " ++ horarioAula aula ++ "\n" ++
                "   Válida para os planos: " ++ intercalate ", " (map show (planosPermitidos aula))