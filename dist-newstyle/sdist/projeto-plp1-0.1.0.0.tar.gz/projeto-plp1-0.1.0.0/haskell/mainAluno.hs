{-# OPTIONS_GHC -Wno-incomplete-patterns #-}
module Main where
import AlunoController
import Aluno
import System.Console.ANSI
import Planos
import Control.Monad
import System.IO
import Control.Concurrent (threadDelay)
import Network.Mail.SMTP (sendMail) 
import Network.Mail.SMTP.Auth 
import Network.Mail.SMTP.Types ()
import Network.Mail.SMTP 
import qualified Network.Mail.Mime (Mail(..), Address(..), simpleMail) 
import Data.Text(pack)
import Data.Char(toUpper)
import Aula
import qualified Data.Text as T
import qualified Data.Text.Lazy as TL
import Network.Mail.SMTP.Types (Address(..))
import Data.List (elemIndex)
import Data.List.Split(splitOn)
import Treino

defineAulas :: [Aula]
defineAulas = [aulaDança, aulaBoxe]
  where
    aulaDança = Aula { nomeAula = "DANÇA COLETIVA",
                       horarioAula = "Segunda e quarta, das 18:00 às 19:30",
                       planosPermitidos = [Light, Gold, Premium]
                     }
    aulaBoxe = Aula { nomeAula = "BOXE",
                      horarioAula = "Terça e Quinta, das 20:00 às 21:30",
                      planosPermitidos = [Premium]
                    }


defineAlunoComTreino :: Aluno
defineAlunoComTreino = alunoComTreino
      where 
      alunoEx = Aluno
            { alunoId = 0
            , nome = "Joao Pedro"
            , cpf = "066.399.304-04"
            , endereço = "Rua 2"
            , contato = "9 88919955"
            , planoAluno = Light
            , treinos = []
            , emDia = False
            , matricula = "001"
            , senha = "jp22"
            , email = "joaoPedro@gmail"
            , aulas = []
            }
      treinoExemplo = Treino
            { tipoTreino = "Peito"
            , exercicios = ["Supino", "Flexão de Braço", "Crucifixo", "Supino Inclinado", "Cross-over", "Supino declinado"]
            }
      alunoComTreino = adicionaTreinoAluno alunoEx treinoExemplo

exibeAulas :: [Aula] -> IO()
exibeAulas [] =  putStrLn "Não há aulas cadastradas."
exibeAulas aulas = mapM_ exibeAula aulas

exibeAula :: Aula -> IO ()
exibeAula aula = do
      putStrLn(show(aula)++"\n\n")

main :: IO ()
main = do 
      loginAluno defineAlunoComTreino
     {- alunoSaida<- criarAluno
      let detalhes = detalhesPlano(planoAluno alunoSaida)
      putStrLn detalhes
      clearScreen
      setCursorPosition 0 0
      putStrLn ("\n\nAAAAAAluno criado!!"++ show(alunoSaida))-}

-- Funçao que inicia a pagina manuseada pelo aluno, necessitando da matricula e senha para acessa
existeMatricula :: String -> IO Bool
existeMatricula strMat = do
    conteudo <- readFile "haskell/Aluno.txt"
    let linhas = lines conteudo
    return (strMat `elem` primeirosElementos linhas)

criarAluno :: [String] -> Aluno
criarAluno [matricula,idStr, nome, cpf, endereco, contato, plano, treinosStr, emDiaStr, senha, email, aulasStr] =
      Aluno
      { matricula = matricula
      ,alunoId = read idStr
      , nome = nome
      , cpf = cpf
      , endereço = endereco
      , contato = contato
      , planoAluno = readPlano plano
      , treinos = []
      , emDia = read emDiaStr
      , senha = senha
      , email = email
      , aulas = []
      }
      where
      readPlano "Light" = Planos.Light
      readPlano "Gold" = Planos.Gold
      readPlano "Premium" = Planos.Premium
      readPlano _ = error "Plano desconhecido"

      
{-recuperaAlunoMatricula:: String-> Aluno
recuperaAlunoMatricula matStr= do
      conexao <- openFile "haskell/Aluno.txt" ReadMode
      conteudo <- hGetContents conexao
            let linhas = lines conteudo
                matriculas = primeirosElementos linhas
                dadosFuncionario = filtrarMatricula matStr linhas
-}




{-filtrarMatricula :: String -> [String] -> [[String]]
filtrarMatricula matriculaStr listaG = do
    let listaP = primeirosElementos listaG
        posicao = posicaoIdLista id listaP
    --sabendo que a posicao da listaP e a mesma da listaG, com os mesmos valores
    return (splitOn "," (listaG !! posicao)) 
-}

loginAluno::Aluno->IO()
loginAluno alunoSaida= do
      limparTerminal  -- funçao que limpa o terminal
      putStrLn "   ==== LOGIN/ALUNO ==== "
      putStr   "> Matrícula: "
      hFlush stdout
      matriculaAluno<- getLine
      matriculaExiste<-existeMatricula matriculaAluno
      if not(matriculaExiste)
            then do putStrLn "nao encontrada"
      else do
            --alunoEncontrado<- recuperaAlunoMatricula matriculaAluno
            if not(matriculaAluno == matricula alunoSaida)
                  then do
                        limparTerminal
                        exibirMensagemTemporaria "\n!! Matricula não encontrada. Tente novamente... !!"
                        loginAluno alunoSaida
            else do  
                  putStr "> Senha: " 
                  hFlush stdout
            senhaAluno<- getLine
            if not(senhaAluno == senha alunoSaida )
                  then do
                        limparTerminal
                        exibirMensagemTemporaria "\n!! Senha incorreta. Tente novamente... !!"
                        loginAluno alunoSaida
                        
            else do
                  exibirMensagemTemporaria "\nCarregando..."
            homeAluno alunoSaida

homeAluno:: Aluno-> IO()
homeAluno alunoAtual = do 
      clearScreen
      setCursorPosition 1 0
      putStrLn "╔═════════════════════════════════════════╗"
      putStrLn ("║              Olá "++ primeiroNome(nome alunoAtual)++" !")
      putStrLn "║                                         ║"
      putStrLn "║   [1] Consultar Plano atual             ║"
      putStrLn "║   [2] Alterar Plano                     ║"
      putStrLn "║   [3] Meus Dados                        ║"
      putStrLn "║   [4] Aulas Coletivas                   ║"
      putStrLn "║   [5] Treinos                           ║"
      putStrLn "║   [6] Realizar Pagamento                ║"
      putStrLn "║                                         ║"
      putStrLn "║   > Digite a opção:                     ║ "
      putStrLn "╚═════════════════════════════════════════╝"
      opçao<- getLine
      case opçao of
            "1"-> exibePlano (alunoAtual)
            "2"-> alterarPlano alunoAtual
            "3"-> meusDados alunoAtual
            "4"-> aulasColetivas alunoAtual
            "5"-> menuTreinos alunoAtual
            "6"-> realizaPagamento alunoAtual
            _ -> do
                  putStr "Opção inválida!!"
                  homeAluno alunoAtual

menuTreinos:: Aluno-> IO()
menuTreinos aluno= do
      limparTerminal   
      putStrLn ("        ======= Meus Treinos =======\n")
      if (length (treinos aluno))==0
            then do
                  putStrLn "\n > Você ainda não possui treinos cadastrados !\n\n [0] Voltar\n"
                  opçao<- getLine
                  case opçao of
                        "0"-> homeAluno aluno
                        _  -> menuTreinos aluno
      else do
            putStrLn (exibeTreinosAluno (treinos aluno))
            putStrLn " [0] Voltar\n"
            opçao<- getLine
            case opçao of
                  "0"-> homeAluno aluno
                  _  -> menuTreinos aluno
                                

aulasColetivas:: Aluno-> IO()
aulasColetivas aluno= do
      limparTerminal
      putStrLn ("        ======= Aulas Coletivas =======\n")
      exibeAulas defineAulas
      putStrLn "\n\n [0] Voltar     [1] Inscrever-se     [2] Minhas aulas"
      opçao<- getLine
      case opçao of
            "0"-> homeAluno aluno
            "1"-> inscriçaoAula aluno
            "2"-> listarAulas aluno
            _ -> do
                  putStrLn "Opção inválida !!"
                  aulasColetivas aluno

listarAulas:: Aluno->IO()
listarAulas aluno= do
      limparTerminal
      putStrLn "    ===== MINHAS AULAS ====\n"
      mapM_ exibeAula (aulas aluno)
      putStrLn "\nPressione ENTER para voltar..."
      saida<- getLine
      aulasColetivas aluno  
                  
inscriçaoAula:: Aluno->IO()
inscriçaoAula aluno= do
      if not(emDia aluno)
            then do
                  putStrLn "\n > Não é possível realizar inscrições com a mensalidade pendente. Efetue o pagamento..."
                  threadDelay (3 * 1000000)
                  aulasColetivas aluno
            else do
                  putStr "\n > Nome da aula: "
                  hFlush stdout
                  aulaInsc<- getLine
                  let aulaInscMaiuscula = map toUpper aulaInsc
                  if  existeAula aulaInscMaiuscula defineAulas
                        then do 
                              if  aulaInscMaiuscula == nomeAula(verificaAula aulaInscMaiuscula defineAulas)
                                    then if planoIncluido aluno (verificaAula aulaInsc defineAulas)
                                          then if (estaInscrito aluno aulaInsc)
                                                then do
                                                      putStrLn " - Você já está Inscrito nessa aula !\n\n>Pressione ENTER para voltar"
                                                      voltar2<-getLine
                                                      homeAluno aluno 
                                          else do        
                                                putStrLn ("\x1b[32m" ++aulaInsc++ " adicionada na sua agenda de aulas." ++ "\x1b[0m")
                                                threadDelay (2 * 1000000)
                                                adicionaAulaAluno (verificaAula aulaInsc defineAulas) aluno
                                    else do
                                    
                                          putStrLn " - O seu Plano não permite a inscrição nesta aula\n   Vá ate a pagina 'Alterar plano' e adquira um plano compatível\n\n >Pressione ENTER para voltar..."
                                          voltar<- getLine
                                          homeAluno aluno
                              else do
                                    putStrLn"\n Aula não encontrada !"
                                    limparTerminal
                                    aulasColetivas aluno
                        else do     
                              putStrLn"\n Aula não encontrada !"
                              threadDelay (2 * 1000000)
                              limparTerminal
                              aulasColetivas aluno        


estaInscrito :: Aluno -> String -> Bool
estaInscrito aluno nomeAulaStr = any (\aula -> nomeAula aula == nomeAulaStr) (aulas aluno)

planoIncluido :: Aluno -> Aula -> Bool
planoIncluido aluno aula = planoAluno aluno `elem` planosPermitidos aula

adicionaAulaAluno:: Aula-> Aluno-> IO()
adicionaAulaAluno aula aluno=do
      let alunoAtualizado = aluno { aulas = aula : aulas aluno }
      putStrLn " * Inscrição realizada com sucesso *"
      homeAluno alunoAtualizado


existeAula:: String-> [Aula]-> Bool
existeAula _ [] = False
existeAula nomeAulaStr (aula:outrasAulas)=
      if nomeAula aula == nomeAulaStr
            then True
            else existeAula nomeAulaStr outrasAulas

verificaAula :: String -> [Aula] -> Aula
verificaAula nomeAulaStr (aula:outrasAulas) = 
      if map toUpper(nomeAula aula) == map toUpper nomeAulaStr
            then aula
            else verificaAula nomeAulaStr outrasAulas

meusDados:: Aluno-> IO() 
meusDados aluno= do
      limparTerminal
      putStrLn ("   ======= "++nome aluno++ " =======\n")
      putStr (exibirAluno aluno)
      putStrLn "\n\n>       [0] Voltar ao menu     [1] Editar dados "
      opçao <- getLine
      case opçao of
            "0"-> homeAluno aluno
            "1"-> editDados aluno
            _ -> meusDados aluno
      
      
editDados:: Aluno-> IO()
editDados aluno = do
      limparTerminal
      putStrLn "> Dado para edição:"
      putStrLn "\n1. Nome"
      putStrLn "2. Endereço"
      putStrLn "3. Contato"
      putStrLn "4. Senha do app"
      putStrLn "5. Email\n>"
      opçao <- getLine
      case opçao of
            "1" -> do 
                  putStrLn " -> Novo nome: "
                  novoNome<- getLine
                  let alunoNovo = aluno{ nome= novoNome}
                  exibirMensagemTemporaria " *Nome atualizado com sucesso*"
                  homeAluno alunoNovo
                  
            "2" -> do 
                  putStrLn " -> Novo endereço: "
                  novoEndereco <- getLine
                  let alunoNovo = aluno { endereço = novoEndereco }
                  exibirMensagemTemporaria " *Endereço atualizado com sucesso*"
                  homeAluno alunoNovo
            "3" -> do 
                  putStrLn " -> Novo contato: "
                  novoContato <- getLine
                  let alunoNovo = aluno { contato = novoContato }
                  exibirMensagemTemporaria " *Contato atualizado com sucesso*"
                  homeAluno alunoNovo
            "4" -> do 
                  putStrLn " -> Nova senha: "
                  novaSenha <- getLine
                  let alunoNovo = aluno { senha = novaSenha }
                  exibirMensagemTemporaria " *Senha atualizada com sucesso*"
                  homeAluno alunoNovo
            "5" -> do 
                  putStrLn " -> Novo email: "
                  novoEmail <- getLine
                  let alunoNovo = aluno { senha = novoEmail }
                  exibirMensagemTemporaria " *Email atualizada com sucesso*"
                  homeAluno alunoNovo
            _ -> do
                  putStrLn "Opção inválida!"
                  exibirMensagemTemporaria " *Opção inválida*"
                  editDados aluno
 
obterPlanoParaAluno :: Aluno -> Plano
obterPlanoParaAluno aluno = case planoAluno aluno of
      Light -> planoLight
      Gold -> planoGold
      Premium -> planoPremium                  

-- Funçao  para enviar um Email de confirmação do pagamento para a academia
enviarEmail :: Aluno-> IO ()
enviarEmail aluno= do
    let planoAtual = obterPlanoParaAluno aluno
     -- Configurar as informações do servidor SMTP
    let from       = Address Nothing (T.pack (email aluno))
        to         = [Address (Just (T.pack "Codefit")) (T.pack "joao.pedro.arruda.silva@ccc.ufcg.edu.br")] --colocar o email aqui (monitor/professor) para correção, envia a mensagem para o email especificado acima
        cc         = []
        bcc        = []
        subject    = T.pack "Pagamento de Mensalidade"
        body       = plainTextPart (TL.pack (nome aluno++" efetuou o pagamento do mês\n R$"++ show (valorMensal planoAtual)++"\n- Matrícula: "++ show(matricula aluno)))
       
    
    let mail = simpleMail from to cc bcc subject [body]
    
    sendMailWithLoginSTARTTLS "smtp.gmail.com" "jpcros40414@gmail.com" "sudx dymy kypg ocez" mail

realizaPagamento:: Aluno-> IO()
realizaPagamento aluno= do
      limparTerminal
      putStrLn "   ==== FINANCEIRO ====\n"
      if emDia aluno
            then do 
                  putStrLn " - Sua mensalidade está em dia !" 
                  putStrLn "\n>Pressione ENTER para voltar..."
                  _ <- getLine -- Aguarda o Enter
                  homeAluno aluno
      else do
            putStrLn " - Mensalidade Pendende."
            putStrLn "\n> Forma de pagamento:   [P]Pix    [D]cartão de debito   [C]cartão de crédito   [B]Boleto"
            hFlush stdout
            opçao <- getLine
            exibirMensagemTemporaria "\n *Processando pagamento...*"
            
            let alunoNovo = aluno{emDia = True}
            putStrLn $ "\x1b[32m" ++ " Pagamento Realizado." ++ "\x1b[0m"
            threadDelay (2 * 1000000)
            enviarEmail aluno
            homeAluno alunoNovo

alterarPlano:: Aluno-> IO()
alterarPlano aluno= do 
      clearScreen
      setCursorPosition 0 0
      putStrLn "> Planos disponíveis: \n"
      let plano1 = detalhesPlano (Planos.Light)
      let plano2 = detalhesPlano (Planos.Gold)
      let plano3 = detalhesPlano (Planos.Premium)
      putStrLn (plano1++"\n")
      putStrLn (plano2++"\n")
      putStrLn (plano3++"\n")
      putStr "\n>Opçao de plano ([L] Light | [G] Gold | [P] Premium): "
      hFlush stdout
      opçao<- getLine
      let planoEscolhido = case opçao of
            "L" -> Planos.Light
            "l" -> Planos.Light
            "G" -> Planos.Gold
            "g" -> Planos.Gold
            "P" -> Planos.Premium
            "p" -> Planos.Premium
            _   -> planoAluno aluno 
                  

      let alunoNovo= aluno {    planoAluno = planoEscolhido, emDia = False }
      putStrLn "\n>Pressione ENTER para confirmar..."
      _ <- getLine -- Aguarda o Enter
      homeAluno alunoNovo

      --alterarPlanoAluno aluno
exibePlano:: Aluno-> IO()
exibePlano aluno = do 
      let plano =detalhesPlano(planoAluno aluno)
      clearScreen
      setCursorPosition 0 0
      putStrLn plano
      putStrLn "\n>Pressione ENTER para voltar..."
      confirma <- getChar
      when (confirma /= '\n') $ void getChar -- Aguarda o Enter
      homeAluno aluno

limparTerminal :: IO ()
limparTerminal = do
      clearScreen
      setCursorPosition 0 0


exibirMensagemTemporaria :: String -> IO ()
exibirMensagemTemporaria msg = do
      putStrLn msg
      threadDelay (3 * 1000000)


primeiroNome :: String -> String
primeiroNome nome = head (words nome)

{-recuperaMatricula:: String-> Bool
recuperaMatricula matricula = 

recuperaSenha:: String-> Bool
recuperaSenha senha= 

recuperaAluno:: String-> Aluno
recuperaAluno matricula-}      